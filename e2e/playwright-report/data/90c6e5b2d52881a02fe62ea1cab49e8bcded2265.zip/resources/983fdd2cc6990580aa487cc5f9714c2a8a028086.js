document.addEventListener('DOMContentLoaded', function() {
  var toggle = document.querySelector('.error-footer .toggle-details');
  var details = document.querySelector('.error-details');

  toggle.addEventListener('click', function(e) {
    e.preventDefault();
    if (!details.classList.contains('active')) {
      details.classList.remove('fadeOut');
      details.classList.add('active', 'animated', 'fadeIn');
      toggle.classList.add('active');
      toggle.textContent = 'Hide details for this error';
    } else {
      details.classList.remove('fadeIn', 'active');
      toggle.classList.remove('active');
      toggle.textContent = 'See details for this error';
    }
  });
}, false);
